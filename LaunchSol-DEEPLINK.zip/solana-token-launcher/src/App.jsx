import React, { useMemo } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { ConnectionProvider, WalletProvider } from '@solana/wallet-adapter-react'
import { SolflareWalletAdapter } from '@solana/wallet-adapter-solflare'
import { BaseSignerWalletAdapter, WalletReadyState } from '@solana/wallet-adapter-base'
import { clusterApiUrl } from '@solana/web3.js'
import { TokenCountProvider } from './context/TokenCountContext.jsx'
import HomePage from './pages/HomePage.jsx'
import SuccessPage from './pages/SuccessPage.jsx'

const NETWORK = import.meta.env.VITE_SOLANA_NETWORK || 'mainnet-beta'
const RPC = import.meta.env.VITE_RPC_ENDPOINT || clusterApiUrl(NETWORK)

class BackpackAdapter extends BaseSignerWalletAdapter {
  name = 'Backpack'
  url = 'https://backpack.app'
  icon = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMTI4IDEyOCIgZmlsbD0ibm9uZSI+PHJlY3Qgd2lkdGg9IjEyOCIgaGVpZ2h0PSIxMjgiIHJ4PSIzMiIgZmlsbD0iI0UzM0UzRiIvPjxwYXRoIGQ9Ik02NCAyOEM0NyAyOCAzNCA0MSAzNCA1OFY2NEgyOEMyNCA2NCAyMCA2OCAyMCA3MlYxMDBDMjAgMTA0IDI0IDEwOCAyOCAxMDhIMTAwQzEwNCAxMDggMTA4IDEwNCAxMDggMTAwVjcyQzEwOCA2OCAxMDQgNjQgMTAwIDY0SDk0VjU4Qzk0IDQxIDgxIDI4IDY0IDI4Wk02NCAzOEM3NiAzOCA4NCA0NiA4NCA1OFY2NEg0NFY1OEM0NCA0NiA1MiAzOCA2NCAzOFpNNjQgNzZDNjkgNzYgNzMgODAgNzMgODVDNzMgODkgNzEgOTIgNjggOTNWOTlINjBWOTNDNTcgOTIgNTUgODkgNTUgODVDNTUgODAgNTkgNzYgNjQgNzZaIiBmaWxsPSJ3aGl0ZSIvPjwvc3ZnPg=='
  _connecting = false
  get connecting() { return this._connecting }
  get readyState() {
    if (typeof window === 'undefined') return WalletReadyState.Unsupported
    return window.backpack?.isBackpack ? WalletReadyState.Installed : WalletReadyState.NotDetected
  }
  get publicKey() { return window.backpack?.publicKey || null }
  get connected() { return !!window.backpack?.isConnected }
  async connect() {
    this._connecting = true
    try { const r = await window.backpack.connect(); this.emit('connect', r.publicKey) }
    catch (e) { this.emit('error', e); throw e }
    finally { this._connecting = false }
  }
  async disconnect() { await window.backpack?.disconnect(); this.emit('disconnect') }
  async signTransaction(tx) { return window.backpack.signTransaction(tx) }
  async signAllTransactions(txs) { return window.backpack.signAllTransactions(txs) }
}

export default function App() {
  const wallets = useMemo(() => [new SolflareWalletAdapter(), new BackpackAdapter()], [])
  return (
    <ConnectionProvider endpoint={RPC}>
      <WalletProvider wallets={wallets} autoConnect={false} onError={(e) => console.warn('Wallet error:', e?.message)}>
        <TokenCountProvider>
          <BrowserRouter>
            <div className="scanline" />
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/success" element={<SuccessPage />} />
            </Routes>
          </BrowserRouter>
        </TokenCountProvider>
      </WalletProvider>
    </ConnectionProvider>
  )
}
